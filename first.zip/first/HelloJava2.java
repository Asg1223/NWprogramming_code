package com.example.first;

public class HelloJava2 {
    public static void main(String[] args) {
        System.out.print("Hello, World");
        System.out.print("Hello, Java ");
    }
}
