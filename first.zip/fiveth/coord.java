package com.example.fiveth;
//課題Q
public class coord {
    double x, y;

    coord() {
        x = y= 10; // 課題48で変更
        System.out.println("coord() x=" + x + " y=" + y);
    }
}
