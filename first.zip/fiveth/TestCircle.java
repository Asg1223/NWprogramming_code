package com.example.fiveth;
//課題Q
public class TestCircle {
    public static void main(String[] args) {
        Circle c = new Circle();
        System.out.println("x = " + c.x + ", y = " + c.y);
    }
}
