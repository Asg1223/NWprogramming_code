package com.example.fiveth;
//課題R
import java.awt.Color;

public class Circle1 extends coord1 {
    Color color;
    double size;

    Circle1() {
        color = Color.BLACK;
        size = 1;
    }
}

