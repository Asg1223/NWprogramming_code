package com.example.fiveth;
//課題Q
import java.awt.Color;

public class Circle extends coord {
    Color color;
    double size;

    Circle() {
        color = Color.BLACK;
        size = 1;
        System.out.println("Circle");
    }
}

