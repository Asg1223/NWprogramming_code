package com.example.fourth.G;

public class CitStudent {
    String no;          // 学生番号
    String name;        // 氏名
    int year;           // 学年
    int grade;          // 成績
    int department;     // 学科 (1:CS, 2:NS)
}
